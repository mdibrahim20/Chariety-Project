<div class="p-6">
    <div class="flex items-center justify-between mb-6">
        <div>
            <h1 class="text-2xl font-bold text-gray-900">Manage Events</h1>
            <p class="mt-1 text-sm text-gray-600">Create and manage Event posts</p>
        </div>
        <a href="{{ route('admin.events.create') }}" class="inline-flex items-center px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700">+ New Event</a>
    </div>

    @if (session()->has('success'))
        <div class="mb-4 rounded bg-green-50 border border-green-200 p-3 text-green-800">{{ session('success') }}</div>
    @endif

    <div class="bg-white rounded-lg border border-gray-200 p-4 mb-4">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
                <label class="text-sm font-medium text-gray-700">Search</label>
                <input type="text" wire:model.live="search" class="w-full rounded-lg border-gray-300" placeholder="Search events...">
            </div>
            <div>
                <label class="text-sm font-medium text-gray-700">Status</label>
                <select wire:model.live="statusFilter" class="w-full rounded-lg border-gray-300">
                    <option value="">All</option>
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                </select>
            </div>
        </div>
    </div>

    <div class="bg-white rounded-lg border border-gray-200 overflow-hidden">
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Title</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Slug</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Actions</th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
                @foreach ($events as $event)
                    <tr>
                        <td class="px-6 py-4">{{ $event->title }}</td>
                        <td class="px-6 py-4 text-sm text-gray-500">{{ $event->slug }}</td>
                        <td class="px-6 py-4">
                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium {{ $event->is_active ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800' }}">
                                {{ $event->is_active ? 'Active' : 'Inactive' }}
                            </span>
                        </td>
                        <td class="px-6 py-4 text-right">
                            <div class="inline-flex gap-2">
                                <a href="{{ route('admin.events.edit', $event->id) }}" class="px-3 py-1.5 text-xs bg-indigo-100 text-indigo-700 rounded">Edit</a>
                                <button wire:click="toggleStatus({{ $event->id }})" class="px-3 py-1.5 text-xs bg-gray-100 text-gray-700 rounded">{{ $event->is_active ? 'Unpublish' : 'Publish' }}</button>
                                <button wire:click="delete({{ $event->id }})" wire:confirm="Delete this event?" class="px-3 py-1.5 text-xs bg-red-100 text-red-700 rounded">Delete</button>
                            </div>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
        <div class="px-6 py-4 border-t border-gray-200">{{ $events->links() }}</div>
    </div>
</div>
