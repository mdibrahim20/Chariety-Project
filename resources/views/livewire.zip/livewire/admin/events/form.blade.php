<div class="p-6">
    <div class="flex items-center justify-between mb-6">
        <div>
            <h1 class="text-2xl font-bold text-gray-900">{{ $event ? 'Edit Event' : 'Create Event' }}</h1>
            <p class="mt-1 text-sm text-gray-600">Event Blog / Details</p>
        </div>
    </div>

    @if (session()->has('error'))
        <div class="mb-4 rounded bg-red-50 border border-red-200 p-3 text-red-800">{{ session('error') }}</div>
    @endif

    <form wire:submit="save" class="space-y-8">
        <div class="bg-white rounded-lg border border-gray-200 p-6">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label class="block text-sm font-medium text-gray-700">Title *</label>
                    <input type="text" wire:model="title" class="w-full rounded-lg border-gray-300" placeholder="Event Title" required>
                    @error('title')<p class="text-sm text-red-600">{{ $message }}</p>@enderror
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700">Slug</label>
                    <input type="text" wire:model="slug" class="w-full rounded-lg border-gray-300" placeholder="event-slug">
                    @error('slug')<p class="text-sm text-red-600">{{ $message }}</p>@enderror
                </div>
                <div class="md:col-span-2">
                    <label class="block text-sm font-medium text-gray-700">Short Summary</label>
                    <textarea wire:model="summary" rows="2" class="w-full rounded-lg border-gray-300" placeholder="Optional short summary..."></textarea>
                    @error('summary')<p class="text-sm text-red-600">{{ $message }}</p>@enderror
                </div>
                <div class="md:col-span-2">
                    <label class="block text-sm font-medium text-gray-700">Content (TinyMCE)</label>
                    <textarea wire:model="content_html" id="content_html" rows="10" class="w-full rounded-lg border-gray-300"></textarea>
                    <p class="mt-1 text-xs text-gray-500">Rich text supported. Script tags will be removed on save.</p>
                    @error('content_html')<p class="text-sm text-red-600">{{ $message }}</p>@enderror
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700">Status</label>
                    <div class="flex items-center gap-3 mt-2">
                        <button type="button" wire:click="$toggle('is_active')" class="relative inline-flex h-6 w-11 items-center rounded-full transition-colors {{ $is_active ? 'bg-indigo-600' : 'bg-gray-200' }}">
                            <span class="inline-block h-4 w-4 transform rounded-full bg-white transition-transform {{ $is_active ? 'translate-x-6' : 'translate-x-1' }}"></span>
                        </button>
                        <span class="text-sm font-semibold {{ $is_active ? 'text-green-600' : 'text-gray-500' }}">{{ $is_active ? 'Active' : 'Inactive' }}</span>
                    </div>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700">Ordering</label>
                    <input type="number" min="0" wire:model="ordering" class="w-full rounded-lg border-gray-300">
                    @error('ordering')<p class="text-sm text-red-600">{{ $message }}</p>@enderror
                </div>
            </div>
        </div>

        <div class="bg-white rounded-lg border border-gray-200 p-6">
            <h2 class="text-lg font-semibold text-gray-900 mb-4">SEO</h2>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label class="block text-sm font-medium text-gray-700">Meta Title</label>
                    <input type="text" wire:model="meta_title" class="w-full rounded-lg border-gray-300">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700">Meta Description</label>
                    <input type="text" wire:model="meta_description" class="w-full rounded-lg border-gray-300">
                </div>
                <div class="md:col-span-2">
                    <label class="block text-sm font-medium text-gray-700">Meta Image</label>
                    @if ($existing_meta_image)
                        <div class="mb-2">
                            <img src="{{ Storage::url($existing_meta_image) }}" alt="Meta" class="h-24 rounded">
                        </div>
                    @endif
                    <input type="file" wire:model="meta_image" accept=".jpg,.jpeg,.png,.webp" class="block w-full text-sm text-gray-500">
                    @error('meta_image')<p class="text-sm text-red-600">{{ $message }}</p>@enderror
                </div>
            </div>
        </div>

        <div class="bg-white rounded-lg border border-gray-200 p-6">
            <h2 class="text-lg font-semibold text-gray-900 mb-4">Gallery Images</h2>
            <input type="file" multiple wire:model="gallery" accept=".jpg,.jpeg,.png,.webp" class="block w-full text-sm text-gray-500">
            <p class="mt-2 text-xs text-gray-500">Upload multiple images. They will be optimized and resized.</p>
            @error('gallery.*')<p class="text-sm text-red-600">{{ $message }}</p>@enderror

            @if ($images && $images->count() > 0)
                <div class="mt-4 grid grid-cols-2 md:grid-cols-4 gap-4">
                    @foreach ($images as $img)
                        <div class="border rounded-lg p-2">
                            <img src="{{ $img->thumb_url }}" alt="thumb" class="w-full h-32 object-cover rounded">
                            <div class="mt-2 flex items-center justify-between">
                                <button type="button" wire:click="setFeatured({{ $img->id }})" class="px-2 py-1 text-xs rounded {{ $event && $event->featured_image_id === $img->id ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700' }}">{{ $event && $event->featured_image_id === $img->id ? 'Featured' : 'Set Featured' }}</button>
                                <button type="button" wire:click="deleteImage({{ $img->id }})" wire:confirm="Delete this image?" class="px-2 py-1 text-xs rounded bg-red-100 text-red-700">Delete</button>
                            </div>
                        </div>
                    @endforeach
                </div>
            @endif
        </div>

        <div class="flex items-center justify-end gap-4 pt-6 border-t border-gray-200">
            <button type="submit" class="inline-flex items-center px-6 py-3 bg-indigo-600 text-white rounded-lg">Save Event</button>
        </div>
    </form>
</div>

@push('scripts')
<script src="https://cdn.tiny.cloud/1/no-api-key/tinymce/7/tinymce.min.js" referrerpolicy="origin"></script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        tinymce.init({
            selector: '#content_html',
            plugins: 'link lists image table code',
            toolbar: 'undo redo | styles | bold italic underline | alignleft aligncenter alignright | bullist numlist | link image table | code',
            height: 400,
            setup: function (editor) {
                editor.on('change', function () {
                    @this.set('content_html', editor.getContent());
                });
            }
        });
    });
</script>
@endpush
