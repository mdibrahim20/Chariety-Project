<div class="p-6">
    <h1 class="text-2xl font-bold mb-4">Contact Page Settings</h1>
    
    <nav class="mb-6 text-sm">
        <ol class="flex space-x-2 text-gray-600">
            <li><a href="/admin/dashboard" class="hover:text-gray-900" wire:navigate>Dashboard</a></li>
            <li>/</li>
            <li class="text-gray-900">Contact Settings</li>
        </ol>
    </nav>

    @if (session()->has('success'))
        <div class="mb-6 bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative" role="alert">
            <span class="block sm:inline">{{ session('success') }}</span>
        </div>
    @endif

    <div class="bg-white rounded-lg shadow-md p-6">
        <form wire:submit.prevent="save">
            <!-- Section Text -->
            <div class="mb-8">
                <h2 class="text-xl font-semibold mb-4 pb-2 border-b">Section Text</h2>
                
                <div class="grid grid-cols-1 gap-6">
                    <div>
                        <label for="badge_label" class="block text-sm font-medium text-gray-700 mb-2">Badge Label (Optional)</label>
                        <input type="text" id="badge_label" wire:model="badge_label" placeholder="e.g., Contact Us"
                               class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                    </div>
                    
                    <div>
                        <label for="main_heading" class="block text-sm font-medium text-gray-700 mb-2">Main Heading</label>
                        <input type="text" id="main_heading" wire:model="main_heading" 
                               class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent @error('main_heading') border-red-500 @enderror">
                        @error('main_heading') <p class="mt-1 text-sm text-red-600">{{ $message }}</p> @enderror
                    </div>
                    
                    <div>
                        <label for="description" class="block text-sm font-medium text-gray-700 mb-2">Description</label>
                        <textarea id="description" wire:model="description" rows="3"
                                  class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"></textarea>
                    </div>
                    
                    <div>
                        <label for="submit_button_text" class="block text-sm font-medium text-gray-700 mb-2">Submit Button Text</label>
                        <input type="text" id="submit_button_text" wire:model="submit_button_text" 
                               class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent @error('submit_button_text') border-red-500 @enderror">
                        @error('submit_button_text') <p class="mt-1 text-sm text-red-600">{{ $message }}</p> @enderror
                    </div>
                </div>
            </div>

            <!-- Google Map -->
            <div class="mb-8">
                <h2 class="text-xl font-semibold mb-4 pb-2 border-b">Google Map</h2>
                
                <div>
                    <label for="google_map_embed" class="block text-sm font-medium text-gray-700 mb-2">Google Map Embed Code (iframe or URL)</label>
                    <textarea id="google_map_embed" wire:model="google_map_embed" rows="4" 
                              placeholder='<iframe src="https://www.google.com/maps/embed?pb=..." width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>'
                              class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent font-mono text-sm"></textarea>
                    <p class="mt-1 text-sm text-gray-500">Paste the embed code from Google Maps</p>
                </div>
            </div>

            <!-- Form Subject Options -->
            <div class="mb-8">
                <h2 class="text-xl font-semibold mb-4 pb-2 border-b">Form Configuration</h2>
                
                <div>
                    <label for="subject_options" class="block text-sm font-medium text-gray-700 mb-2">Subject Dropdown Options (comma-separated)</label>
                    <input type="text" id="subject_options" wire:model="subject_options" 
                           placeholder="e.g., Nothing,Donation,Volunteer,General Inquiry"
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                    <p class="mt-1 text-sm text-gray-500">Separate options with commas</p>
                </div>
            </div>

            <!-- Card 1: Phone -->
            <div class="mb-8">
                <h2 class="text-xl font-semibold mb-4 pb-2 border-b">Card 1: Call Us Today</h2>
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div class="md:col-span-2 flex items-center">
                        <input type="checkbox" id="card_phone_enabled" wire:model="card_phone_enabled" class="w-4 h-4 text-blue-600 rounded focus:ring-blue-500">
                        <label for="card_phone_enabled" class="ml-2 text-sm font-medium text-gray-700">Enable Phone Card</label>
                    </div>
                    
                    <div>
                        <label for="card_phone_title" class="block text-sm font-medium text-gray-700 mb-2">Card Title</label>
                        <input type="text" id="card_phone_title" wire:model="card_phone_title" 
                               class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                    </div>
                    
                    <div>
                        <label for="card_phone_subtitle" class="block text-sm font-medium text-gray-700 mb-2">Subtitle (Optional)</label>
                        <input type="text" id="card_phone_subtitle" wire:model="card_phone_subtitle" 
                               class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                    </div>
                    
                    <div>
                        <label for="card_phone_1" class="block text-sm font-medium text-gray-700 mb-2">Phone Number 1</label>
                        <input type="text" id="card_phone_1" wire:model="card_phone_1" 
                               class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                    </div>
                    
                    <div>
                        <label for="card_phone_2" class="block text-sm font-medium text-gray-700 mb-2">Phone Number 2 (Optional)</label>
                        <input type="text" id="card_phone_2" wire:model="card_phone_2" 
                               class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                    </div>
                </div>
            </div>

            <!-- Card 2: Email -->
            <div class="mb-8">
                <h2 class="text-xl font-semibold mb-4 pb-2 border-b">Card 2: Mail Information</h2>
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div class="md:col-span-2 flex items-center">
                        <input type="checkbox" id="card_email_enabled" wire:model="card_email_enabled" class="w-4 h-4 text-blue-600 rounded focus:ring-blue-500">
                        <label for="card_email_enabled" class="ml-2 text-sm font-medium text-gray-700">Enable Email Card</label>
                    </div>
                    
                    <div>
                        <label for="card_email_title" class="block text-sm font-medium text-gray-700 mb-2">Card Title</label>
                        <input type="text" id="card_email_title" wire:model="card_email_title" 
                               class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                    </div>
                    
                    <div>
                        <label for="card_email_subtitle" class="block text-sm font-medium text-gray-700 mb-2">Subtitle (Optional)</label>
                        <input type="text" id="card_email_subtitle" wire:model="card_email_subtitle" 
                               class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                    </div>
                    
                    <div>
                        <label for="card_email_1" class="block text-sm font-medium text-gray-700 mb-2">Email Address 1</label>
                        <input type="email" id="card_email_1" wire:model="card_email_1" 
                               class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent @error('card_email_1') border-red-500 @enderror">
                        @error('card_email_1') <p class="mt-1 text-sm text-red-600">{{ $message }}</p> @enderror
                    </div>
                    
                    <div>
                        <label for="card_email_2" class="block text-sm font-medium text-gray-700 mb-2">Email Address 2 (Optional)</label>
                        <input type="email" id="card_email_2" wire:model="card_email_2" 
                               class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent @error('card_email_2') border-red-500 @enderror">
                        @error('card_email_2') <p class="mt-1 text-sm text-red-600">{{ $message }}</p> @enderror
                    </div>
                </div>
            </div>

            <!-- Card 3: Location -->
            <div class="mb-8">
                <h2 class="text-xl font-semibold mb-4 pb-2 border-b">Card 3: Our Location</h2>
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div class="md:col-span-2 flex items-center">
                        <input type="checkbox" id="card_location_enabled" wire:model="card_location_enabled" class="w-4 h-4 text-blue-600 rounded focus:ring-blue-500">
                        <label for="card_location_enabled" class="ml-2 text-sm font-medium text-gray-700">Enable Location Card</label>
                    </div>
                    
                    <div>
                        <label for="card_location_title" class="block text-sm font-medium text-gray-700 mb-2">Card Title</label>
                        <input type="text" id="card_location_title" wire:model="card_location_title" 
                               class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                    </div>
                    
                    <div>
                        <label for="card_location_subtitle" class="block text-sm font-medium text-gray-700 mb-2">Subtitle (Optional)</label>
                        <input type="text" id="card_location_subtitle" wire:model="card_location_subtitle" 
                               class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                    </div>
                    
                    <div class="md:col-span-2">
                        <label for="card_location_address" class="block text-sm font-medium text-gray-700 mb-2">Address</label>
                        <textarea id="card_location_address" wire:model="card_location_address" rows="3"
                                  class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"></textarea>
                    </div>
                </div>
            </div>

            <div class="flex gap-3">
                <button type="submit" class="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium">
                    Save Changes
                </button>
                <a href="/admin/dashboard" wire:navigate class="px-6 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 font-medium">
                    Cancel
                </a>
            </div>
        </form>
    </div>
</div>
