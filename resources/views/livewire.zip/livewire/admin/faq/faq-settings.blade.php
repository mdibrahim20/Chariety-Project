<div class="container-fluid px-4">
    <h1 class="mt-4">FAQ Settings</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="/admin/dashboard">Dashboard</a></li>
        <li class="breadcrumb-item active">FAQ Settings</li>
    </ol>

    @if (session()->has('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            {{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    @endif

    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-cog me-1"></i>
            FAQ Page Settings
        </div>
        <div class="card-body">
            <form wire:submit.prevent="save">
                <div class="mb-3">
                    <label for="section_heading" class="form-label">Section Heading</label>
                    <input type="text" class="form-control @error('section_heading') is-invalid @enderror" 
                           id="section_heading" wire:model="section_heading" 
                           placeholder="e.g., Frequently Asked Questions">
                    @error('section_heading') <div class="invalid-feedback">{{ $message }}</div> @enderror
                    <div class="form-text">This heading will appear at the top of the FAQ section.</div>
                </div>

                <div class="d-flex gap-2">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-1"></i> Save Changes
                    </button>
                    <a href="/admin/dashboard" class="btn btn-secondary" wire:navigate>
                        <i class="fas fa-times me-1"></i> Cancel
                    </a>
                </div>
            </form>
        </div>
    </div>
</div>
