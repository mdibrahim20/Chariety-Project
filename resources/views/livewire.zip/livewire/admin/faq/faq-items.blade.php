<div class="container-fluid px-4">
    <h1 class="mt-4">FAQ Items</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="/admin/dashboard">Dashboard</a></li>
        <li class="breadcrumb-item active">FAQ Items</li>
    </ol>

    @if (session()->has('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            {{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    @endif

    <div class="row">
        <div class="col-md-5">
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-{{ $editingId ? 'edit' : 'plus' }} me-1"></i>
                    {{ $editingId ? 'Edit FAQ Item' : 'Add New FAQ Item' }}
                </div>
                <div class="card-body">
                    <form wire:submit.prevent="save">
                        <div class="mb-3">
                            <label for="faq_category_id" class="form-label">Category</label>
                            <select class="form-select @error('faq_category_id') is-invalid @enderror" 
                                    id="faq_category_id" wire:model="faq_category_id">
                                <option value="">Select a category</option>
                                @foreach ($categories as $category)
                                    <option value="{{ $category->id }}">{{ $category->name }}</option>
                                @endforeach
                            </select>
                            @error('faq_category_id') <div class="invalid-feedback">{{ $message }}</div> @enderror
                        </div>

                        <div class="mb-3">
                            <label for="question" class="form-label">Question</label>
                            <input type="text" class="form-control @error('question') is-invalid @enderror" 
                                   id="question" wire:model="question" placeholder="Enter your question">
                            @error('question') <div class="invalid-feedback">{{ $message }}</div> @enderror
                        </div>

                        <div class="mb-3">
                            <label for="answer" class="form-label">Answer</label>
                            <textarea class="form-control @error('answer') is-invalid @enderror" 
                                      id="answer" wire:model="answer" rows="5" 
                                      placeholder="Enter the answer"></textarea>
                            @error('answer') <div class="invalid-feedback">{{ $message }}</div> @enderror
                            <div class="form-text">You can use basic HTML tags for formatting</div>
                        </div>

                        <div class="mb-3">
                            <label for="display_order" class="form-label">Display Order</label>
                            <input type="number" class="form-control @error('display_order') is-invalid @enderror" 
                                   id="display_order" wire:model="display_order" min="0">
                            @error('display_order') <div class="invalid-feedback">{{ $message }}</div> @enderror
                        </div>

                        <div class="mb-3">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="is_active" wire:model="is_active">
                                <label class="form-check-label" for="is_active">
                                    Active
                                </label>
                            </div>
                        </div>

                        <div class="d-flex gap-2">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save me-1"></i> {{ $editingId ? 'Update' : 'Create' }}
                            </button>
                            @if ($editingId)
                                <button type="button" class="btn btn-secondary" wire:click="cancelEdit">
                                    <i class="fas fa-times me-1"></i> Cancel
                                </button>
                            @endif
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-md-7">
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-list me-1"></i>
                    FAQ Items List
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <label for="filterCategoryId" class="form-label">Filter by Category</label>
                        <select class="form-select" id="filterCategoryId" wire:model.live="filterCategoryId">
                            <option value="">All Categories</option>
                            @foreach ($categories as $category)
                                <option value="{{ $category->id }}">{{ $category->name }}</option>
                            @endforeach
                        </select>
                    </div>

                    @if ($items->count() > 0)
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th>Category</th>
                                        <th>Question</th>
                                        <th>Order</th>
                                        <th>Status</th>
                                        <th width="120">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($items as $item)
                                        <tr>
                                            <td><span class="badge bg-primary">{{ $item->category->name }}</span></td>
                                            <td>{{ Str::limit($item->question, 60) }}</td>
                                            <td>{{ $item->display_order }}</td>
                                            <td>
                                                @if ($item->is_active)
                                                    <span class="badge bg-success">Active</span>
                                                @else
                                                    <span class="badge bg-secondary">Inactive</span>
                                                @endif
                                            </td>
                                            <td>
                                                <button class="btn btn-sm btn-info" wire:click="edit({{ $item->id }})">
                                                    <i class="fas fa-edit"></i>
                                                </button>
                                                <button class="btn btn-sm btn-danger" 
                                                        wire:click="delete({{ $item->id }})"
                                                        onclick="return confirm('Are you sure you want to delete this FAQ item?')">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>

                        <div class="mt-3">
                            {{ $items->links() }}
                        </div>
                    @else
                        <p class="text-muted text-center py-4">No FAQ items found. Create your first FAQ item!</p>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>
