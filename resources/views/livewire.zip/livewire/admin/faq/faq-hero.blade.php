<div class="container-fluid px-4">
    <h1 class="mt-4">FAQ Hero Section</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="/admin/dashboard">Dashboard</a></li>
        <li class="breadcrumb-item active">FAQ Hero</li>
    </ol>

    @if (session()->has('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            {{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    @endif

    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-image me-1"></i>
            Hero Section Settings
        </div>
        <div class="card-body">
            <form wire:submit.prevent="save">
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="page_title" class="form-label">Page Title</label>
                        <input type="text" class="form-control @error('page_title') is-invalid @enderror" 
                               id="page_title" wire:model="page_title">
                        @error('page_title') <div class="invalid-feedback">{{ $message }}</div> @enderror
                    </div>
                    <div class="col-md-6">
                        <label for="breadcrumb_home_label" class="form-label">Breadcrumb Home Label</label>
                        <input type="text" class="form-control @error('breadcrumb_home_label') is-invalid @enderror" 
                               id="breadcrumb_home_label" wire:model="breadcrumb_home_label">
                        @error('breadcrumb_home_label') <div class="invalid-feedback">{{ $message }}</div> @enderror
                    </div>
                </div>

                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="breadcrumb_current_label" class="form-label">Breadcrumb Current Label</label>
                        <input type="text" class="form-control @error('breadcrumb_current_label') is-invalid @enderror" 
                               id="breadcrumb_current_label" wire:model="breadcrumb_current_label">
                        @error('breadcrumb_current_label') <div class="invalid-feedback">{{ $message }}</div> @enderror
                    </div>
                    <div class="col-md-6">
                        <label for="overlay_opacity" class="form-label">Overlay Opacity (%)</label>
                        <input type="number" class="form-control @error('overlay_opacity') is-invalid @enderror" 
                               id="overlay_opacity" wire:model="overlay_opacity" min="0" max="100">
                        @error('overlay_opacity') <div class="invalid-feedback">{{ $message }}</div> @enderror
                    </div>
                </div>

                <div class="row mb-3">
                    <div class="col-md-6">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="is_active" wire:model="is_active">
                            <label class="form-check-label" for="is_active">
                                Active
                            </label>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="overlay_enabled" wire:model="overlay_enabled">
                            <label class="form-check-label" for="overlay_enabled">
                                Enable Overlay
                            </label>
                        </div>
                    </div>
                </div>

                <div class="mb-3">
                    <label for="background_image" class="form-label">Background Image (1920x600, max 10MB)</label>
                    <input type="file" class="form-control @error('background_image') is-invalid @enderror" 
                           id="background_image" wire:model="background_image" accept="image/*">
                    @error('background_image') <div class="invalid-feedback">{{ $message }}</div> @enderror
                    
                    @if ($background_image)
                        <div class="mt-2">
                            <p class="text-muted">Preview:</p>
                            <img src="{{ $background_image->temporaryUrl() }}" class="img-thumbnail" style="max-height: 200px">
                        </div>
                    @elseif ($current_background_image)
                        <div class="mt-2">
                            <p class="text-muted">Current Image:</p>
                            <img src="{{ asset('storage/' . $current_background_image) }}" class="img-thumbnail" style="max-height: 200px">
                            <button type="button" class="btn btn-danger btn-sm ms-2" wire:click="deleteImage" 
                                    onclick="return confirm('Are you sure you want to delete this image?')">
                                Delete Image
                            </button>
                        </div>
                    @endif
                </div>

                <div class="d-flex gap-2">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-1"></i> Save Changes
                    </button>
                    <a href="/admin/dashboard" class="btn btn-secondary" wire:navigate>
                        <i class="fas fa-times me-1"></i> Cancel
                    </a>
                </div>
            </form>
        </div>
    </div>
</div>
